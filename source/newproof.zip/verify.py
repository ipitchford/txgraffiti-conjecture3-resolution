# Independent verifier: pure brute force, ascending-size subset search. Different algorithm class from check.c.
import sys, itertools

def parse_g6(s):
    n = ord(s[0]) - 63
    bits = []
    for c in s[1:]:
        v = ord(c) - 63
        bits += [(v >> (5 - b)) & 1 for b in range(6)]
    adj = [set() for _ in range(n)]
    k = 0
    for j in range(1, n):
        for i in range(j):
            if bits[k]: adj[i].add(j); adj[j].add(i)
            k += 1
    return n, adj

def exact_i(n, adj):
    V = range(n)
    for k in range(1, n + 1):
        for S in itertools.combinations(V, k):
            Ss = set(S)
            if any(b in adj[a] for a, b in itertools.combinations(S, 2)): continue
            dom = set().union(*[adj[v] | {v} for v in S])
            if len(dom) == n: return k
    return None

def exact_mu(n, adj):
    E = [(i, j) for j in range(n) for i in range(j) if j in adj[i]]
    for k in range(0, len(E) + 1):
        for Msub in itertools.combinations(E, k):
            used = set()
            ok = True
            for a, b in Msub:
                if a in used or b in used: ok = False; break
                used.add(a); used.add(b)
            if not ok: continue
            if all(a in used or b in used for a, b in E): return k
    return None

for line in sys.stdin:
    line = line.strip()
    if not line: continue
    n, adj = parse_g6(line)
    print(line, exact_i(n, adj), exact_mu(n, adj))
