/* check.c — exact tester for the TxGraffiti conjecture i(G) <= mu*(G) on regular graphs.
 * Reads graph6 on stdin (from nauty-geng). n <= 32.
 * Modes: "exact"  : compute exact i and mu* for every graph (validation / equality stats)
 *        "filter" : sound fast-pass — if some maximal independent set has size <= ceil(m/(2D-1))
 *                   then i <= LB(mu*) <= mu*, certified pass; survivors get exact treatment.
 * Any violator (i > mu*) is printed with graph6, n, i, mu*, gamma.
 * Compile: gcc -O3 -march=native -o check check.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

typedef uint32_t vset;   /* vertex set,  n <= 32 */
typedef uint64_t eset;   /* edge set,    m <= 64 */

static int N;                 /* order */
static int M;                 /* size (number of edges) */
static int DEG;               /* max degree (regular: the degree) */
static vset adjc[32];         /* closed neighbourhoods N[v] */
static vset adjo[32];         /* open neighbourhoods  N(v)  */
static int  eu[64], ev[64];   /* edge endpoints */
static eset einc[32];         /* edges incident to vertex v */
static vset FULLV;
static eset FULLE;

/* ---------- graph6 parsing ---------- */
static int parse_g6(const char *s) {
    int n = s[0] - 63;
    if (n < 1 || n > 32) return -1;           /* one-byte order only (n <= 62 anyway) */
    memset(adjo, 0, sizeof(adjo));
    int pos = 1, bit = 0, k = 0;
    unsigned val = s[1] - 63;
    for (int j = 1; j < n; j++)
        for (int i = 0; i < j; i++) {
            if (bit == 6) { pos++; val = s[pos] - 63; bit = 0; }
            if (val & (1u << (5 - bit))) { adjo[i] |= 1u << j; adjo[j] |= 1u << i; }
            bit++; k++;
        }
    N = n; M = 0; DEG = 0;
    for (int v = 0; v < n; v++) {
        adjc[v] = adjo[v] | (1u << v);
        int d = __builtin_popcount(adjo[v]);
        if (d > DEG) DEG = d;
    }
    memset(einc, 0, sizeof(einc));
    for (int j = 1; j < n; j++)
        for (int i = 0; i < j; i++)
            if (adjo[i] & (1u << j)) { eu[M] = i; ev[M] = j; einc[i] |= 1ull << M; einc[j] |= 1ull << M; M++; }
    FULLV = (n == 32) ? 0xFFFFFFFFu : ((1u << n) - 1);
    FULLE = (M == 64) ? ~0ull : ((1ull << M) - 1);
    return n;
}

/* ---------- exact i(G): minimum maximal independent set (branch & bound) ---------- */
static int best_i;
static vset best_i_set;
static void rec_i(vset D, vset I, int size) {
    if (size >= best_i) return;
    if (D == FULLV) { best_i = size; best_i_set = I; return; }
    vset und = FULLV & ~D;
    int U = __builtin_popcount(und);
    int need = (U + DEG) / (DEG + 1);            /* each new vertex dominates <= DEG+1 */
    if (size + need >= best_i) return;
    /* pick undominated vertex with fewest addable candidates (all candidates are outside D) */
    int bw = -1, bc = 99; vset bcand = 0;
    vset t = und;
    while (t) {
        int w = __builtin_ctz(t); t &= t - 1;
        vset cand = adjc[w] & ~D;                 /* addable vertices covering w */
        int c = __builtin_popcount(cand);
        if (c < bc) { bc = c; bw = w; bcand = cand; if (c == 1) break; }
    }
    (void)bw;
    while (bcand) {
        int x = __builtin_ctz(bcand); bcand &= bcand - 1;
        rec_i(D | adjc[x], I | (1u << x), size + 1);
    }
}
static int exact_i(void) { best_i = N + 1; best_i_set = 0; rec_i(0, 0, 0); return best_i; }

/* ---------- exact mu*(G): minimum maximal matching (branch & bound) ---------- */
static int best_m;
static eset best_m_set;
static void rec_m(eset domE, vset Vm, eset Msel, int size) {
    if (size >= best_m) return;
    if (domE == FULLE) { best_m = size; best_m_set = Msel; return; }
    eset undE = FULLE & ~domE;
    int U = __builtin_popcountll(undE);
    int cap = 2 * DEG - 1;                        /* each edge dominates <= 2*DEG-1 edges */
    int need = (U + cap - 1) / cap;
    if (size + need >= best_m) return;
    int e = __builtin_ctzll(undE);                /* first undominated edge */
    int u = eu[e], v = ev[e];
    /* every maximal matching extending Msel must contain an addable edge meeting {u,v} */
    eset cand = (einc[u] | einc[v]);
    while (cand) {
        int f = __builtin_ctzll(cand & -cand) , dummy; (void)dummy;
        f = __builtin_ctzll(cand); cand &= cand - 1;
        int a = eu[f], b = ev[f];
        if ((Vm >> a & 1) || (Vm >> b & 1)) continue;      /* not addable */
        rec_m(domE | einc[a] | einc[b], Vm | (1u << a) | (1u << b), Msel | (1ull << f), size + 1);
    }
}
static int exact_mu(void) { best_m = M + 1; best_m_set = 0; rec_m(0, 0, 0, 0); return best_m; }

/* ---------- exact gamma(G): minimum dominating set (for violators only) ---------- */
static int best_g;
static void rec_g(vset D, int size) {
    if (size >= best_g) return;
    if (D == FULLV) { best_g = size; return; }
    vset und = FULLV & ~D;
    int U = __builtin_popcount(und);
    int need = (U + DEG) / (DEG + 1);
    if (size + need >= best_g) return;
    int bw = -1, bc = 99;
    vset t = und;
    while (t) { int w = __builtin_ctz(t); t &= t - 1;
        int c = __builtin_popcount(adjc[w]);
        if (c < bc) { bc = c; bw = w; } }
    vset cand = adjc[bw];
    while (cand) { int x = __builtin_ctz(cand); cand &= cand - 1; rec_g(D | adjc[x], size + 1); }
}
static int exact_gamma(void) { best_g = N + 1; rec_g(0, 0); return best_g; }

/* ---------- greedy maximal independent set, randomized, size-minimizing ---------- */
static uint64_t rng_s;
static inline uint32_t rnd(void) { rng_s ^= rng_s << 13; rng_s ^= rng_s >> 7; rng_s ^= rng_s << 17; return (uint32_t)rng_s; }
static int greedy_mis(void) {                     /* returns size of one maximal independent set */
    vset D = 0; int size = 0;
    while (D != FULLV) {
        int bx = -1, bg = -1, ties = 0;
        vset free_ = FULLV & ~D;
        vset t = free_;
        while (t) {
            int x = __builtin_ctz(t); t &= t - 1;
            int g = __builtin_popcount(adjc[x] & ~D);
            if (g > bg) { bg = g; bx = x; ties = 1; }
            else if (g == bg && (rnd() % (++ties)) == 0) bx = x;
        }
        D |= adjc[bx]; size++;
    }
    return size;
}

int main(int argc, char **argv) {
    int filter_mode = (argc > 1 && strcmp(argv[1], "filter") == 0);
    int dump_mode   = (argc > 1 && strcmp(argv[1], "dump") == 0);
    int tries = (argc > 2) ? atoi(argv[2]) : 32;
    rng_s = 0x9E3779B97F4A7C15ull;
    char line[256];
    long long total = 0, viol = 0, eq = 0, survivors = 0, hard = 0;
    while (fgets(line, sizeof line, stdin)) {
        int L = strlen(line); while (L && (line[L-1] == '\n' || line[L-1] == '\r')) line[--L] = 0;
        if (!L) continue;
        if (parse_g6(line) < 0) { fprintf(stderr, "bad g6: %s\n", line); return 2; }
        total++;
        int cap = 2 * DEG - 1;
        int LBmu = (M + cap - 1) / cap;           /* mu* >= ceil(m/(2D-1)) */
        if (filter_mode) {
            int ok = 0;
            for (int t = 0; t < tries; t++) if (greedy_mis() <= LBmu) { ok = 1; break; }
            if (ok) continue;                     /* certified: i <= LBmu <= mu* */
            survivors++;
            int iv = exact_i();
            if (iv <= LBmu) continue;
            hard++;
            int mv = exact_mu();
            if (iv <= mv) { if (iv == mv) eq++; continue; }
            int gv = exact_gamma();
            printf("VIOLATION g6=%s n=%d m=%d i=%d mu*=%d gamma=%d iset=%08x mset=%016llx\n",
                   line, N, M, iv, mv, gv, best_i_set, (unsigned long long)best_m_set);
            fflush(stdout); viol++;
        } else {
            int iv = exact_i();
            int mv = exact_mu();
            if (dump_mode) printf("%s %d %d\n", line, iv, mv);
            if (iv > mv) {
                int gv = exact_gamma();
                printf("VIOLATION g6=%s n=%d m=%d i=%d mu*=%d gamma=%d iset=%08x mset=%016llx\n",
                       line, N, M, iv, mv, gv, best_i_set, (unsigned long long)best_m_set);
                fflush(stdout); viol++;
            } else if (iv == mv) eq++;
        }
    }
    fprintf(stderr, "graphs=%lld violations=%lld equalities(i=mu*)=%lld survivors=%lld hard=%lld\n",
            total, viol, eq, survivors, hard);
    return viol ? 1 : 0;
}
