#!/bin/bash
# Reproduction script: TxGraffiti Conjecture 3 verification session, 2026-08-05.
# Conjecture (Davila-Brimkov-Pepper, arXiv:2507.17780, posed 2020):
#   every r-regular graph (r>0) satisfies i(G) <= mu*(G).
# Requires: nauty (nauty-geng), gcc, python3.
gcc -O3 -o check check.c

# Validation anchors and cross-implementation agreement (see verify.py):
for n in 8 10 12; do nauty-geng -q -c -d3 -D3 $n | ./check dump 32 > c$n.txt; done
# python3 verify.py < same graph6 streams reproduces both invariant columns exactly.

# Exhaustive sweeps (all previously reported totals; zero violations everywhere):
nauty-geng -q -c -d3 -D3 14 | ./check exact 32     # 509 graphs
nauty-geng -q -c -d3 -D3 16 | ./check exact 32     # 4060 graphs, 1470 equalities
nauty-geng -q -c -d3 -D3 18 | ./check filter 32    # 41301 graphs
for r in 0 1 2 3; do nauty-geng -q -c -d3 -D3 20 $r/4 | ./check filter 32; done
#   shards: 117329+114795+142787+135578 = 510489 = A002851(20)
for n in 18 20 22; do nauty-geng -q -c -d3 -D3 -b $n | ./check filter 32; done   # bipartite cubic
nauty-geng -q -c -d4 -D4 12 | ./check exact 32; nauty-geng -q -c -d4 -D4 13 | ./check exact 32
nauty-geng -q -c -d4 -D4 14 | ./check filter 32
nauty-geng -q -c -d5 -D5 12 | ./check exact 32
nauty-geng -q -c -d6 -D6 12 | ./check filter 32

# Targeted exact-DIM (dominating-induced-matching) model, validating the
# order-threshold lemma (no exact-DIM cubic counterexample for n < 40,
# via Zhang-Peitl-Szeider 2024: smallest unsatisfiable (3,4)-CNF has 16 clauses):
python3 dimgen.py 20 60000 2   | ./check filter 32
python3 dimgen.py 30 3000000 7 | ./check filter 32   # 1431483 sampled in-session
