import sys, random
def g6(n, adj):
    bits=[]
    for j in range(1,n):
        for i in range(j):
            bits.append(1 if (adj[i]>>j)&1 else 0)
    while len(bits)%6: bits.append(0)
    s=chr(n+63)
    for k in range(0,len(bits),6):
        v=0
        for b in bits[k:k+6]: v=(v<<1)|b
        s+=chr(v+63)
    return s
def gen(n, rng):
    s=3*n//10; ne=2*s; w=2*n//5      # endpoints 0..ne-1 (edge j = (2j,2j+1)), W = ne..ne+w-1
    stubs=[]
    for x in range(w): stubs += [ne+x]*3
    for _ in range(200):
        rng.shuffle(stubs)
        adj=[0]*n; ok=True
        for j in range(s):
            a,b=2*j,2*j+1
            adj[a]|=1<<b; adj[b]|=1<<a
        for e in range(ne):
            u1,u2=stubs[2*e],stubs[2*e+1]
            if u1==u2: ok=False; break
            adj[e]|=(1<<u1)|(1<<u2); adj[u1]|=1<<e; adj[u2]|=1<<e
        if ok: return adj
    return None
def main():
    n=int(sys.argv[1]); cnt=int(sys.argv[2]); seed=int(sys.argv[3])
    rng=random.Random(seed); out=sys.stdout
    made=0
    while made<cnt:
        a=gen(n,rng)
        if a is None: continue
        out.write(g6(n,a)+'\n'); made+=1
main()
