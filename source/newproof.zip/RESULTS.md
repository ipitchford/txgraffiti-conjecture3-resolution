# Verification report: TxGraffiti Conjecture 3 (independent domination vs minimum maximal matching in regular graphs)

**Date of computation:** 5 August 2026. **Attribution:** anonymous agentic pipeline.

## Target

Conjecture 3 of R. Davila, B. Brimkov and R. Pepper, *In Reverie Together: Ten Years of Mathematical Discovery with a Machine Collaborator* (arXiv:2507.17780), machine-posed in 2020 and open at the time of computation (bounded-search claim; see Caveats):

> If G is an r-regular graph with r > 0, then i(G) ≤ μ\*(G), and this bound is sharp.

Here i(G) is the independent domination number (minimum size of a maximal independent set) and μ\*(G) the minimum maximal matching number (equivalently the edge domination number γₑ). The cases r ≤ 2 are trivially true; both invariants are additive over components, so connected graphs of degree r ≥ 3 suffice. Since γ ≤ i always, the conjecture strictly implies the conjecture of Baste, Fürst, Henning, Mohr and Rautenbach (*Discrete Applied Mathematics* 285 (2020) 343–349) that γ(G) ≤ γₑ(G) for regular graphs, which remains open in general.

## Methods

Two independently written implementations: `check.c` (branch-and-bound with sound pruning; modes `exact`, `filter`, `dump`; the `filter` fast path certifies i ≤ ⌈m/(2Δ−1)⌉ ≤ μ\* via randomized greedy maximal independent sets and is one-sided sound; survivors receive exact treatment) and `verify.py` (pure brute force, ascending subset size). Graph generation by `nauty-geng` with residue/modulus sharding; the exact commands are in `run.sh`. The generator `dimgen.py` samples exact-DIM cubic graphs (see Lemma below) via a (2,3)-biregular configuration model.

**Validation.** The two implementations agree on both invariants for every connected cubic graph of orders 8, 10, 12 (109 graphs) and on five hand-computed anchors (K₄: 1 ≤ 2; K₃,₃, C₅, Petersen: equality; Q₃: 2 ≤ 3). Generation counts match the known enumeration sequences A002851, A006820, A006821 throughout, and the four order-20 shards sum to 510,489 exactly.

## Results (zero violations in every line)

| Class | Orders (graphs) |
|---|---|
| cubic connected, exhaustive | 8–18 (5; 19; 85; 509; 4,060; 41,301) and 20 (510,489 in four shards) |
| cubic bipartite connected, exhaustive | 18; 20; 22 (149; 703; 4,132) |
| 4-regular connected, exhaustive | 12; 13; 14 (1,544; 10,778; 88,168) |
| 5-regular connected, exhaustive | 12 (7,848) |
| 6-regular connected, exhaustive | 12 (7,849) |
| structured cubic set to order 32 | 55 graphs: all GP(n,k), 5 ≤ n ≤ 16; flower snarks J₃, J₅, J₇; Heawood, Pappus, Desargues, Möbius–Kantor, McGee, Nauru, dodecahedron, Frucht, truncated tetrahedron and cube (21 equalities) |
| exact-DIM cubic, randomized | order 20: 60,000 samples; order 30: 1,431,483 samples |

Equality i = μ\* is frequent (1,470 of 4,060 at cubic order 16; 21 of 55 structured graphs), so the bound, if true, is razor-tight. Consequence of the sweeps: any counterexample of minimum order among cubic graphs has more than 20 vertices; among bipartite cubic graphs, more than 22.

## Lemma (order threshold for the dominating-induced-matching regime)

For cubic G, μ\*(G) ≥ ⌈m/5⌉ = ⌈3n/10⌉, with equality precisely when G admits a **dominating induced matching** (DIM) M: then |M| = 3n/10, n ≡ 0 (mod 10), V(M) induces exactly M, the unmatched set W is independent with |W| = 2n/5, every matched vertex has exactly two neighbours in W, and every w ∈ W has three matched neighbours.

**Lemma.** *If a cubic graph G admits a dominating induced matching and n(G) < 40, then i(G) ≤ μ\*(G).*

*Proof.* Orient each M-edge j as (Aⱼ, Bⱼ) and introduce a Boolean variable xⱼ (true = choose Aⱼ). Any choice of one endpoint per M-edge is automatically independent (V(M) induces exactly M) and dominates V(M) (each vertex is chosen or is the partner of a chosen vertex). It dominates w ∈ W iff a chosen endpoint neighbours w. If w is adjacent to both endpoints of one edge it is always dominated; otherwise its three matched neighbours lie on three distinct edges and yield a clause of exactly three literals on three distinct variables. Each variable occurs in at most four clauses (two per endpoint). The resulting system is therefore a (3,4)-CNF — every clause exactly three distinct literals, every variable in at most four clauses — with at most |W| = 2n/5 ≤ 14 < 16 clauses. By the exhaustive determination of Zhang, Peitl and Szeider (SAT 2024; arXiv:2405.16149, Table 1), every unsatisfiable (3,4)-CNF has at least 16 clauses; hence the system is satisfiable, and a satisfying assignment yields a maximal independent set of size |M| = 3n/10 = μ\*(G). ∎

The lemma covers n ∈ {10, 20, 30} (connectivity is not used). The 1,431,483 order-30 samples above test its prediction in territory no exhaustive sweep reaches; all satisfy i ≤ 9 = μ\*, and both i = 8 and i = 9 occur, confirming that sets meeting W below transversal size exist and that the second half of the analysis is necessary.

**The sharp frontier.** At n = 40 the transversal system has 12 variables and up to 16 clauses — exactly the minimum size at which unsatisfiable (3,4)-formulas exist, and there every variable occurs exactly four times. A hypothetical exact-DIM cubic counterexample of order 40 requires (a) a minimum-size unsatisfiable (3,4)-formula that is polarity-balanced (every variable twice positive, twice negative) — any such formula is *automatically realisable* as an exact-DIM cubic graph of order 40 by the incidence construction above — and additionally (b) that no mixed independent dominating set (k unchosen edges compensated by a ≤ k vertices of W, subject to the domination and independence constraints) attains size ≤ 12. Whether a polarity-balanced minimum instance exists is decidable from the Zhang–Peitl–Szeider search infrastructure and is the single crispest open computational question this analysis isolates.

## Caveats

Openness of the conjecture is a bounded-search claim as of 5 August 2026, not a certified fact. All sweeps are finite computations and imply nothing uniform beyond their stated ranges; the lemma is a proved statement but is conditional on the published minimum in arXiv:2405.16149, which was not independently re-derived here. Equality counts in `filter` mode are deliberate undercounts (the greedy certificate bypasses exact computation). Orders 22+ cubic, 24+ bipartite cubic, 14+ quintic, 13+ sextic, 15+ quartic were not swept.
